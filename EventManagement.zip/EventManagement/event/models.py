from django.db import models


class Events(models.Model):
    eventName = models.CharField(max_length=50)
    description = models.CharField(max_length=255)
    location = models.CharField(max_length=100)
    fromDate = models.DateTimeField(auto_now=False, blank=True)
    toDate = models.DateTimeField(auto_now=False, blank=True)
    deadline = models.DateTimeField(auto_now=False, blank=True)
    hostEmail = models.CharField(max_length=320)
    hostPassword = models.CharField(max_length=16)
    imageURL = models.CharField(max_length=255)


