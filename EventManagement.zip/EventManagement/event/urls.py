from django.urls import path
from . import views

urlpatterns = [
    path('', views.event),
    path('eventRegistration/', views.eventRegistration),
    path('save/', views.save)
]