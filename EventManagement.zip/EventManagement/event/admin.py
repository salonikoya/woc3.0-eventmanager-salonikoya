from django.contrib import admin
from .models import Events


class EventAdmin(admin.ModelAdmin):
    list_display=('eventName','description','location','fromDate','toDate','deadline','hostEmail',
                  'hostPassword','imageURL')



admin.site.register(Events,EventAdmin)