from django.shortcuts import render
from django.http import HttpResponse
from . models import Events


def event(request):
    events = Events.objects.all()
    return render(request, 'allEvents.html', {'events': events})


def eventRegistration(request):
    return render(request, 'eventRegistration.html')


def save(request):
    if request.method == 'POST':
            event = Events()
            event.eventName = request.POST.get('eventName')
            event.description = request.POST.get('description')
            event.location = request.POST.get('location')
            event. fromDate  = request.POST.get('fromDate')
            event. toDate  = request.POST.get('toDate')
            event.deadline = request.POST.get('deadline')
            event.hostEmail = request.POST.get('email')
            event.hostPassword = request.POST.get('password')
            event.imageURL = request.POST.get('imageURL')

            event.save()
            events = Events.objects.all()
            return render(request, 'allEvents.html',{'events': events})