from django.db import models


class Participant(models.Model):
    participantName = models.CharField(max_length=50)
    contact = models.BigIntegerField(max_length=10)
    email = models.EmailField(max_length=100)
    event = models.CharField(max_length=50)
    registrationType = models.CharField(max_length=11)
    people = models.IntegerField(max_length=10)

