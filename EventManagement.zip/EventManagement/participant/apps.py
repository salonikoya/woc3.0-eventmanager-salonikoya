from django.apps import AppConfig


class ParticipantConfig(AppConfig):
    name = 'participant'
