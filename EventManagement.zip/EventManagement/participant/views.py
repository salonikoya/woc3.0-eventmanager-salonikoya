from django.shortcuts import render
from django.http import HttpResponse
from . models import Participant


def participant(request):
    participant = Participant.objects.all()
    return render(request, 'allParticipants.html', {'participant': participant})


def participantRegistration(request):
    return render(request, 'participantRegistration.html')


def save(request):
    if request.method == 'POST':
        participant = Participant()
        participant.participantName = request.POST.get('participantName')
        participant.contact = request.POST.get('contact')
        participant.email = request.POST.get('email')
        participant.event  = request.POST.get('event')
        participant.registrationType = request.POST.get('registrationType')
        participant.people = request.POST.get('people')
        participant.save()
        events = Events.objects.all()
        return render(request, 'allParticipants.html',{'participants': participant})