from django.urls import path
from . import views

urlpatterns = [
    path('', views.participant),
    path('participantRegistration/', views.participantRegistration),
    path('save/', views.save)
]